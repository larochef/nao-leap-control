JNAOqi. Remote library for Nao in Java
======================================


This library makes it possible to run some code
from your desktop to interact with naoqi

git repository:
http://github/com/aldebaran/jnaoqi

Mailing list:
naoqi-dev@aldebaran-robotics.com

Documentation:
http://www.aldebaran-robotics.com/documentation/dev/java/index.html

Maintainers:
Dimitri Merejkowsky <dmerejkowsky@aldebaran-robotics.com>
David Houssin <dhoussin@aldebaran-robotics.com>
